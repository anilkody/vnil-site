/** @type {import('next').NextConfig} */
const nextConfig = {
  async redirects() {
    return [
      {
        source: '/hello',
        destination: '/talk',
        permanent: true,
      },
      {
        source: '/home',
        destination: '/',
        permanent: false,
      },
      {
        source: '/case-study',
        destination: '/work',
        permanent: true,
      },
      {
        source: '/case-study/:slug',
        destination: '/work/:slug',
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
